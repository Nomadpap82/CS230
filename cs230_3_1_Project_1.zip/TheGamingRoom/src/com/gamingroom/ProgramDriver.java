package com.gamingroom;

/**
 * Main driver class for the game application
 * CS230 3-1 Project 1
 * Author: Joshua Hale
 * Date: 07/12/2024
 */
public class ProgramDriver {
    public static void main(String[] args) {
        // Get the singleton instance of GameService
        GameService service = GameService.getInstance();

        // Add a game and print its details
        Game game1 = service.addGame("Game 1");
        System.out.println(game1);

        // Add a team to the game and print its details
        Team team1 = game1.addTeam("Team 1");
        System.out.println(team1);

        // Add a player to the team and print its details
        Player player1 = team1.addPlayer("Player 1");
        System.out.println(player1);

        // Print the current state of the GameService to show all games
        System.out.println(service);
    }
}