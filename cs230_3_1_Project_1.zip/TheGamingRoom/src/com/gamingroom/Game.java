package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * Class representing a game
 */
public class Game extends Entity {
    private List<Team> teams = new ArrayList<>();

    /**
     * Constructor with id and name parameters
     * 
     * @param id    the unique identifier
     * @param name  the name of the game
     */
    public Game(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a team to the game if the team name is unique
     * 
     * @param name  the name of the team
     * @return the added or existing team
     */
    public Team addTeam(String name) {
        for (Team team : teams) {
            if (team.getName().equals(name)) {
                return team;
            }
        }
        Team newTeam = new Team(GameService.getNextTeamId(), name);
        teams.add(newTeam);
        return newTeam;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s %-5d %-15s\n", "Game:", id, name));
        for (Team team : teams) {
            sb.append("  ").append(team).append("\n");
        }
        return sb.toString();
    }
}
