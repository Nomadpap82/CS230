package com.gamingroom;

/**
 * Class to test the Singleton pattern implementation
 */
public class SingletonTester {
    public void testSingleton() {
        // Get two instances of GameService
        GameService service1 = GameService.getInstance();
        GameService service2 = GameService.getInstance();

        // Check if both instances are the same
        if (service1 == service2) {
            System.out.println("Singleton pattern test passed.");
        } else {
            System.out.println("Singleton pattern test failed.");
        }
    }
}
