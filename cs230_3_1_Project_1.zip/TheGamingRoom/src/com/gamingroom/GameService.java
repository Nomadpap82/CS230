package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * Singleton class to manage game services
 */
public class GameService {
    // Single instance of GameService
    private static GameService service = null;
    
    // List to store games
    private List<Game> games = new ArrayList<>();
    
    // Static variables for unique identifiers
    private static long nextGameId = 1;
    private static long nextTeamId = 1;
    private static long nextPlayerId = 1;

    // Private constructor to prevent instantiation
    private GameService() {}

    /**
     * Returns the single instance of GameService
     * 
     * @return the singleton instance
     */
    public static GameService getInstance() {
        if (service == null) {
            service = new GameService();
        }
        return service;
    }

    /**
     * Adds a game if the game name is unique
     * 
     * @param name  the name of the game
     * @return the added or existing game
     */
    public Game addGame(String name) {
        for (Game game : games) {
            if (game.getName().equals(name)) {
                return game;
            }
        }
        Game newGame = new Game(nextGameId++, name);
        games.add(newGame);
        return newGame;
    }

    /**
     * Gets the next unique team ID
     * 
     * @return the next team ID
     */
    public static long getNextTeamId() {
        return nextTeamId++;
    }

    /**
     * Gets the next unique player ID
     * 
     * @return the next player ID
     */
    public static long getNextPlayerId() {
        return nextPlayerId++;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("GameService [games=\n");
        for (Game game : games) {
            sb.append("  ").append(game).append("\n");
        }
        sb.append("]");
        return sb.toString();
    }
}
