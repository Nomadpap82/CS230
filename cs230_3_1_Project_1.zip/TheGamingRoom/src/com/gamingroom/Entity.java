package com.gamingroom;

/**
 * Abstract base class for all entities in the game
 */
public abstract class Entity {
    protected long id;
    protected String name;

    /**
     * Constructor with id and name parameters
     * 
     * @param id    the unique identifier
     * @param name  the name of the entity
     */
    public Entity(long id, String name) {
        this.id = id;
        this.name = name;
    }

    /**
     * Gets the unique identifier
     * 
     * @return the id
     */
    public long getId() {
        return id;
    }

    /**
     * Gets the name of the entity
     * 
     * @return the name
     */
    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return String.format("%-10s %-5d %-15s", "Entity:", id, name);
    }
}
