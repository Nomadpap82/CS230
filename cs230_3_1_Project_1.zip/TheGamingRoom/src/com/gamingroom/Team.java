package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * Class representing a team
 */
public class Team extends Entity {
    private List<Player> players = new ArrayList<>();

    /**
     * Constructor with id and name parameters
     * 
     * @param id    the unique identifier
     * @param name  the name of the team
     */
    public Team(long id, String name) {
        super(id, name);
    }

    /**
     * Adds a player to the team if the player name is unique
     * 
     * @param name  the name of the player
     * @return the added or existing player
     */
    public Player addPlayer(String name) {
        for (Player player : players) {
            if (player.getName().equals(name)) {
                return player;
            }
        }
        Player newPlayer = new Player(GameService.getNextPlayerId(), name);
        players.add(newPlayer);
        return newPlayer;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-10s %-5d %-15s\n", "Team:", id, name));
        for (Player player : players) {
            sb.append("    ").append(player).append("\n");
        }
        return sb.toString();
    }
}

