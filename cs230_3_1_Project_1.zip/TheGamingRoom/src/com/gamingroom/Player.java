package com.gamingroom;

/**
 * Class representing a player
 */
public class Player extends Entity {
    /**
     * Constructor with id and name parameters
     * 
     * @param id    the unique identifier
     * @param name  the name of the player
     */
    public Player(long id, String name) {
        super(id, name);
    }

    @Override
    public String toString() {
        return String.format("%-10s %-5d %-15s", "Player:", id, name);
    }
}
