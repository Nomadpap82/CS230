package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.AuthenticationException;
import io.dropwizard.auth.Authenticator;
import io.dropwizard.auth.basic.BasicCredentials;

import java.util.Optional;

public class GameAuthenticator implements Authenticator<BasicCredentials, GameUser> {
    @Override
    public Optional<GameUser> authenticate(BasicCredentials credentials) throws AuthenticationException {
        // Finish the authenticate method based on BasicAuth Security Example for new GameUser
        if ("password".equals(credentials.getPassword())) {
            return Optional.of(new GameUser(credentials.getUsername()));
        }
        return Optional.empty();
    }
}

