package com.gamingroom.gameauth.controller;

import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

// Add annotation for GET and Path for gameusers
@Path("/gameusers")
@Produces(MediaType.APPLICATION_JSON)
public class RESTClientController {

    @GET
    public String getGameUsers() {
        // Method implementation here
        return "List of game users";
    }
}